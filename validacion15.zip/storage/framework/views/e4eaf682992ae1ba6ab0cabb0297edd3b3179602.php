
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('usuarios.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="intro-y flex items-center mt-8">
    <h2 class="text-lg font-medium mr-auto">
        Usuarios
    </h2>
</div>
<!-- BEGIN: Profile Info -->
<div class="grid grid-cols-12 gap-6 mt-5">
    <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
        <a class="btn btn-primary shadow-md mr-2" data-tw-toggle="modal"
        data-tw-target="#large-modal-size-preview">Crear nuevo usuario</a>


    </div>
    <!-- BEGIN: Data List -->
    <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
        <div class="overflow-x-auto">
        <table class="table table-report -mt-2">
            <thead>
                <tr>
                    <th class="whitespace-nowrap">ID</th>
                    <th class="whitespace-nowrap">Usuario</th>
                    
                    <th class="text-center whitespace-nowrap">Contraseña</th>
                    <th class="text-center whitespace-nowrap">Estudiante</th>
                    <th class="text-center whitespace-nowrap">Modificado</th>
                    <th class="text-center whitespace-nowrap">ACTIONS</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="intro-x">
                    <td><?php echo e($user->id); ?></td>
                    <td>
                        <a href="" class="font-medium whitespace-nowrap"><?php echo e($user->email); ?></a>
                    </td>
                    
                    <td class="text-center"><?php echo e($user->password_confirm); ?></td>

                    <td class="text-center"><?php echo e($user->nombres); ?> <?php echo e($user->apellidos); ?></td>
                    <td class="text-center">

                        <?php if($user->tipo_mod==1): ?>

                        <div class="bg-success/20 text-success rounded px-2 mt-1.5">
                         <strong>Registrado</strong> por <strong><?php echo e($user->mod_user); ?></strong>
                        </div>
                        <?php elseif($user->tipo_mod==2): ?>
                        <div class="bg-success/20 text-success rounded px-2 mt-1.5">
                           <strong>Actualizado</strong> por <strong><?php echo e($user->mod_user); ?></strong>
                        </div>
                        <?php endif; ?>
                    </td>

                    <td class="table-report__action w-56">
                        <div class="flex justify-center items-center">
                            <a class="flex items-center mr-3" href="javascript:;"> <i data-lucide="check-square" class="w-4 h-4 mr-1"></i> Edit </a>
                            <a class="flex items-center text-danger" data-tw-toggle="modal"
                             data-tw-target="#delete-confirmation-modal<?php echo e($user->id); ?>">
                              <i data-lucide="trash-2" class="w-4 h-4 mr-1"></i> Delete </a>
                        </div>
                    </td>
                </tr>
                <?php echo $__env->make("usuarios.modal-eli", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
    </div>
    <!-- END: Data List -->
</div>

<!-- END: Profile Info -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\validacion\resources\views/usuarios/index.blade.php ENDPATH**/ ?>