
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('alumnos.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="intro-y flex items-center mt-3">
    <a href="<?php echo e(route('alumnos.index')); ?>" class="btn btn-primary-soft w-24 mr-1 mb-2">Atras</a>
    
</div>
<div class="intro-y flex items-center mt-3 mb-4">
    <h2 class="text-lg font-medium mr-auto">
        Editar de Alumno
    </h2>
</div>
<?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal-dialog modal-xl">
    <div class="modal-content">
        <form action="<?php echo e(route('editaralumno',$alum->id)); ?>" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal-body grid grid-cols-12 gap-4">
               <div class="col-span-12 sm:col-span-4 input-form">
                    <label for="modal-form-1" class="form-label">Nombres</label>
                    <input id="validation-form-2" type="text" class="form-control form-control-rounded"
                    placeholder="Nombres" name="nombres" value="<?php echo e($alum->nombres); ?>">
                </div>
                <div class="col-span-12 sm:col-span-4 input-form">
                    <label for="modal-form-2" class="form-label">Apellidos</label>
                    <input id="modal-form-2" type="text" class="form-control form-control-rounded"
                     placeholder="Apellidos" name="apellidos" value="<?php echo e($alum->apellidos); ?>">
                </div>
                <div class="col-span-12 sm:col-span-4 input-form">
                    <label for="modal-form-1" class="form-label">DNI</label>
                    <input id="modal-form-1" type="number" class="form-control form-control-rounded"
                    placeholder="76232421" name="dni" value="<?php echo e($alum->dni); ?>">
                 </div>
                 <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                 <div class="col-span-12 sm:col-span-12">
                    <h2><strong>Credenciales del alumno</strong></h2>
                    <label for="modal-form-2" class="form-label">Email (Usuario)</label>
                    <input id="modal-form-2" type="email" class="form-control form-control-rounded"
                    value="<?php echo e($user->email); ?>" name="email" required>
                </div>
                <div class="col-span-12 sm:col-span-12">
                    <label for="modal-form-1" class="form-label">Contraseña</label>
                    <input id="modal-form-1" type="text" class="form-control form-control-rounded"
                    value="<?php echo e($user->password_confirm); ?>" name="password_confirm" required>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
               
                <div class="col-span-12 sm:col-span-6">
                <input id="modal-form-2" type="hidden" value="<?php echo e(Auth::user()->name); ?>" name="mod_user">
                <input id="modal-form-2" type="hidden" value="1" name="tipo_mod">
                
            </div>
            
             
           <div class="text-center">
           <?php $__currentLoopData = $certificados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                         <a data-tw-toggle="modal"
                          data-tw-target="#editar-certi<?php echo e($cer->id); ?>" class="btn btn-primary">
                          Certificado - <strong><?php echo e($cer->codigo_cer); ?></strong></a>
           <?php echo $__env->make("alumnos.modal-edit-certi", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <div class="modal-footer">
            
             <button type="submit" class="btn btn-primary w-20">Actualizar</button>
           </div> <!-- END: Modal Footer -->
        </form>
            </div> 
            
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- END: Profile Info -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\validacion\resources\views/alumnos/edit.blade.php ENDPATH**/ ?>