
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('alumnos.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="intro-y flex items-center mt-3">
    <a href="<?php echo e(route('alumnos.index')); ?>" class="btn btn-primary-soft w-24 mr-1 mb-2">Atras</a>
    
</div>
<div class="intro-y flex items-center mt-3 mb-4">
    <h2 class="text-lg font-medium mr-auto">
        Editar de Alumno
    </h2>
</div>
<?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal-dialog modal-xl">
    <div class="modal-content">
        <form action="<?php echo e(route('editaralumno',$alum->id)); ?>" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal-body grid grid-cols-12 gap-4">
               <div class="col-span-12 sm:col-span-4 input-form">
                    <label for="modal-form-1" class="form-label">Nombres</label>
                    <input id="validation-form-2" type="text" class="form-control form-control-rounded"
                    placeholder="Nombres" name="nombres" value="<?php echo e($alum->nombres); ?>">
                </div>
                <div class="col-span-12 sm:col-span-4 input-form">
                    <label for="modal-form-2" class="form-label">Apellidos</label>
                    <input id="modal-form-2" type="text" class="form-control form-control-rounded"
                     placeholder="Apellidos" name="apellidos" value="<?php echo e($alum->apellidos); ?>">
                </div>
                <div class="col-span-12 sm:col-span-4 input-form">
                    <label for="modal-form-1" class="form-label">DNI</label>
                    <input id="modal-form-1" type="number" class="form-control form-control-rounded"
                    placeholder="76232421" name="dni" value="<?php echo e($alum->dni); ?>">
                 </div>
                <div class="col-span-12 sm:col-span-3 input-form">
                    <label for="modal-form-2" class="form-label">Codigo de Certificado</label>
                    <input id="modal-form-2" type="text" class="form-control form-control-rounded"
                     placeholder="codigo_cer" name="codigo_cer" value="<?php echo e($alum->codigo_cer); ?>">
                </div>
                <div class="col-span-12 sm:col-span-3 input-form">
                    <label for="modal-form-1" class="form-label">Inicio de Clases</label>
                    <input id="modal-form-1" type="date" class="form-control form-control-rounded"
                   name="inicio" value="<?php echo e($alum->inicio); ?>">
                 </div>
                <div class="col-span-12 sm:col-span-3 input-form">
                    <label for="modal-form-2" class="form-label">Fin de Clases</label>
                    <input id="modal-form-2" type="date" class="form-control form-control-rounded"
                      name="final" value="<?php echo e($alum->final); ?>">
                </div>

                <div class="col-span-12 sm:col-span-3 input-form">
                    <label for="modal-form-1" class="form-label">Codigo de Curso</label>
                    <input id="modal-form-1" type="text" class="form-control form-control-rounded"
                   name="codigo_cur" value="<?php echo e($alum->codigo_cur); ?>">
                 </div>
                <div class="col-span-12 sm:col-span-6">
                    <label for="modal-form-2" class="form-label">Foto Perfil</label>
                    <input id="modal-form-2" type="file" class="form-control form-control-rounded"
                      name="image" accept="image/*" value="<?php echo e($alum->nombres); ?>">

                      <div class="w-20 h-20 sm:w-24 sm:h-24 flex-none lg:w-32 lg:h-32 image-fit relative">
                        <img  class="rounded-full" src="/images-cer/<?php echo e($alum->image); ?>" />
                        <div class="absolute mb-1 mr-1 flex items-center
                         justify-center bottom-0 right-0 bg-primary rounded-full p-2">
                           </div>
                    </div>
                </div>
                
               
                <div class="col-span-12 sm:col-span-6">
                    <label for="modal-form-2" class="form-label">Foto certificados</label>
                    <input id="modal-form-2" type="file" class="form-control form-control-rounded"
                      name="images[]" multiple accept="image/*">
                     
                <div class="mx-6 pb-8 mt-3">
                <div class="responsive-mode">
                    <?php if($alum->alumnoImages): ?>
                        
                    <?php $__currentLoopData = $alum->alumnoImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="h-32 px-2">
                        <div class="h-full bg-slate-100 dark:bg-darkmode-400 rounded-md">
                            <img src="/<?php echo e($img->image); ?>" />
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <?php endif; ?>
                </div>
                </div>
                </div>
            </div>
               
                <div class="col-span-12 sm:col-span-6">
                <input id="modal-form-2" type="hidden" value="<?php echo e(Auth::user()->name); ?>" name="mod_user">
                <input id="modal-form-2" type="hidden" value="1" name="tipo_mod">

            </div>
             <!-- END: Modal Body -->

           

            <div class="modal-footer">
                
                 <button type="submit" class="btn btn-primary w-20">Actualizar</button>
               </div> <!-- END: Modal Footer -->

            </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- END: Profile Info -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\validacion\resources\views/alumnos/edit.blade.php ENDPATH**/ ?>