
<?php $__env->startSection('content'); ?>

<div class="intro-y flex items-center mt-8">
    <a href="<?php echo e(route('alumnos.index')); ?>" class="btn btn-elevated-rounded-primary w-24 mr-1 mb-2">Atras</a>
    
</div>
<h2 class="text-lg font-medium text-center">
    Detalle del Alumno 
</h2>
<div class="grid grid-cols-12 gap-6 mt-5">
    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- BEGIN: Profile Menu -->
    <div class="col-span-12 lg:col-span-12 2xl:col-span-3 flex lg:block flex-col-reverse">
        <div class="intro-y box mt-5 lg:mt-0">
            <div class="relative flex items-center p-5">
            
                <div class="ml-4 mr-auto">
                    <h2> Información Personal</h2> 
                    <div class="font-medium text-base"><?php echo e($alum->nombres); ?></div>
                    <div class="text-slate-500"><?php echo e($alum->apellidos); ?></div>
                    <div class="text-slate-500 mr-5 sm:mr-5"><?php echo e($alum->dni); ?></div>
                </div>
            </div>
            
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- END: Profile Menu -->
    <?php $__currentLoopData = $certificados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
    <div class="col-span-6 lg:col-span-6 2xl:col-span-9">
        <div class="grid grid-cols-12 gap-6">
            <div class="intro-y box col-span-12 2xl:col-span-8">
                <div class="flex items-center px-5 py-3 border-b border-slate-200/60 dark:border-darkmode-400">
                    <h2 class="font-medium text-base mr-auto">
                        Certificado <strong><?php echo e($cer->codigo_cer); ?></strong><br>
                        Codigo Curso: <strong><?php echo e($cer->codigo_cur); ?></strong><br>
                        Fecha: Inicio: <strong><?php echo e($cer->inicio); ?></strong> / Final:<strong><?php echo e($cer->final); ?></strong><br>
                    </h2>
                </div>
                <div class="mx-6 pb-8">
                    <div class="fade-mode"> 
                        <?php $__currentLoopData = $certificados_imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cerima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                        <?php if($cer->id==$cerima->cer_id): ?>
                        <div class="h-64 px-2">
                            <div class="h-full image-fit rounded-md overflow-hidden"> 
                               <img src="/<?php echo e($cerima->image); ?>" />
                            </div> 
                           </div>
                        <?php else: ?>
                            
                        <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> 
                </div> 
            </div> 
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>


<!-- END: Profile Info -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\validacion\resources\views/alumnos/detalles.blade.php ENDPATH**/ ?>