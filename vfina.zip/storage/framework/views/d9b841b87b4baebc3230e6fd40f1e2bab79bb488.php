<div id="large-modal-size-preview" class="modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
             <!-- BEGIN: Modal Header -->
             <div class="modal-header">
                <h2 class="font-medium text-base mr-auto">Registro de Usuarios</h2>
            </div> <!-- END: Modal Header -->
          <?php if($errors->any()): ?>

              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="alert alert-outline-danger alert-dismissible
             show flex items-center mb-2" role="alert">
              <i data-lucide="alert-octagon" class="w-6 h-6 mr-2"></i>
              <?php echo e($error); ?>

              <button type="button" class="btn-close" data-tw-dismiss="alert"
                aria-label="Close"> <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php endif; ?>
        <form  method="POST" action="<?php echo e(route('validar-registro')); ?>">
            <?php echo csrf_field(); ?>
                <div class="modal-body grid grid-cols-12 gap-4">
                    <div class="col-span-12 sm:col-span-6">
                        <label for="modal-form-1" class="form-label">Nombres</label>
                        <input id="modal-form-1" type="text" class="form-control form-control-rounded"
                        placeholder="Nombres" name="name">
                     </div>
                    <div class="col-span-12 sm:col-span-6">
                        <label for="modal-form-2" class="form-label">Email (Usuario)</label>
                        <input id="modal-form-2" type="email" class="form-control form-control-rounded"
                         placeholder="email@gmail.com" name="email">
                    </div>
                    <div class="col-span-12 sm:col-span-6">
                        <label for="modal-form-1" class="form-label">Contraseña</label>
                        <input id="modal-form-1" type="text" class="form-control form-control-rounded"
                        placeholder="**********" name="password">
                     </div>
                     <div class="col-span-12 sm:col-span-12">
                         <!-- BEGIN: Basic Select --> <div>
                             <label>Alumno</label>
                              <div class="mt-2"> 
                               
                                <select data-placeholder="Selecciona un alumno"
                                 class="tom-select w-full" name="id_estudiante">
                                    <option selected>Busca al alumno</option>
                                    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($alum->id); ?>"><?php echo e($alum->dni); ?> -  <?php echo e($alum->nombres); ?> <?php echo e($alum->apellidos); ?></option> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div> <!-- END: Basic Select --> 
                        <input type="hidden" name="mod_user" value="<?php echo e(Auth::user()->name); ?>">
                        <input type="hidden" name="tipo_mod" value="1">

                     </div>
                </div> <!-- END: Modal Body -->

                <div class="modal-footer">
                    <button type="button" data-tw-dismiss="modal" class="btn btn-outline-secondary
                     w-20 mr-1">Cancel</button>
                     <button type="submit" class="btn btn-primary w-20">Crear</button>
                   </div> <!-- END: Modal Footer -->
        </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\validacion\resources\views/usuarios/modal.blade.php ENDPATH**/ ?>